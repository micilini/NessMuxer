#ifndef X264_CONFIG_H
#define X264_CONFIG_H

#define X264_GPL           1
#define X264_INTERLACED    1
#define X264_BIT_DEPTH     0
#define X264_CHROMA_FORMAT 0

#define X264_REV           0
#define X264_REV_DIFF      0
#define X264_VERSION       "unknown"
#define X264_POINTVER      "unknown"

#endif